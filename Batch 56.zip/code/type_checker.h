// Group 56
// Rishabh Garg (2014A7PS065P)
// M Sharat Chandra (2014A7PS108P)

#ifndef _type_checker
#define _type_checker
#include "ast.h"
#include "symbolTable.h"
#include <stdio.h>

void type_check(TREE_NODE_PTR node);

#endif